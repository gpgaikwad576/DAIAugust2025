from logging.config import valid_ident

flight_log = input("Enter flight log: ")
valid =True
ln = len(flight_log)
if(ln<6): valid =False
i =1
cancel =0
opposite_moves = {
    'U':'D','D':'U','L':'R','R':'L'
}
while(i<ln):
    val = opposite_moves[flight_log[i]]
    valb = flight_log[i-1]
    if( val == valb): cancel+=1
    i+=1

if(cancel >3): valid =True
print("Drone Flight Log: ",flight_log)
print("Total Commands: ",ln)
print("Cancel Moves Detected: ",cancel)
if(valid): print("Path is Valid!",end="")
else: print("Path is not Valid!",end="")
print("Final Flight Analysis Complete")
