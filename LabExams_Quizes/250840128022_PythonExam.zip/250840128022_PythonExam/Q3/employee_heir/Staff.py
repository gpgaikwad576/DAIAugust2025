class Staff:
    _staff_id_iter =1
    def __init__(self,name):
        self._staff_id = Staff._staff_id_iter
        self._name = name
        self._id_valid =True
        self._name_valid = True
        if self._staff_id <= 0: self._id_valid =False  # validation flagging
        if(len(self._name)==0): self._name_valid =False
        Staff._staff_id_iter+=1

    def is_valid(self):     #validation logic
        error_line =""
        if(not self._id_valid):
            error_line +="staffid must be >0 |"

        if (not self._name_valid):
            error_line += "name must notr be empty"

        return error_line

    def calculate_pay(self):
        return  0.0