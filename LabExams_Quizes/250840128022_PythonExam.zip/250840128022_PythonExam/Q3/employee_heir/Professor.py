from typing import override

from Q3.employee_heir.Staff import Staff


class Professor(Staff):
    def __init__(self,name,annual_sal):
        super().__init__(name)
        self.__annual_sal = annual_sal
        self.__sal_valid = True
        if (self.__annual_sal < 0): self.__sal_valid = False

    def is_valid(self):
        error_line = ""
        if (not self.__sal_valid):
            error_line += "salary must be  >=0"
        return error_line

    @override
    def calculate_pay(self): #calc logic
        return self.__annual_sal/12
