from typing import override

from Q3.employee_heir.Staff import Staff


class TeachAssist(Staff):
    def __init__(self, name, hourly_rate,hours_worked):
        super().__init__(name)
        self.__hourly_rate = hourly_rate
        self.__hours_worked = hours_worked
        self._hour_rate_valid = True
        self._hours_valid = True
        if (self.__hourly_rate < 0): self._hour_rate_valid = False
        if (self.__hours_worked < 0): self._hours_valid = False

    def is_valid(self):
        error_line = ""
        if (not self._hour_rate_valid):
            error_line += "hour rate must be  >=0 |"

        if (not self._hours_valid):
            error_line += "hours worked must be  >=0"

        return error_line      #return error line

    @override
    def calculate_pay(self):
        return self.__hourly_rate * self.__hours_worked


