from Q3.employee_heir.Professor import Professor
from Q3.employee_heir.TeachAssist import TeachAssist

John = Professor("Prof. John",144000)
Maria = Professor("Maria",108000)
Priya = TeachAssist("TA Priya",60,120)
David = TeachAssist("David",50,-10)
staffs= [John,Priya,Maria,David]    #staff in school

# for s in staffs:
#     error = s.is_valid()
#     if len(error)>0:
#         print("Error for ", s._name, ": ", error)
#         continue
#     print(s._name,"(",type(s).__name__,") Monthly Pay: $",s.calculate_pay())

for s in staffs:
    error = s.is_valid()
    try:
        if len(error) > 0:                                 #raise value error and continue for next
            raise ValueError(error)
        print(s._name, "(", type(s).__name__, ") Monthly Pay: $", s.calculate_pay())  #print desired output
    except ValueError:
        print("Error for ", s._name, ": ", error)


print("\nPayroll processing Completed")


