
def clean_feedback(raw_feedback):
    rf =[s.lower() for s in raw_feedback ]
    i=0
    while(i < len(rf)):
        if(rf[i]  in ['.',',','?','!']):
            rf.pop(i)
        i+=1
    return ''.join(rf)


def analyze_feedback(raw_feedback,cleaned_str):
    arr = cleaned_str.split(' ')
    st =set(arr)
    print(st)
    cnt =0
    for s in cleaned_str:
        if (s in ['a','e','i','o','u']):
            cnt+=1

    return {'Original_length':len(raw_feedback),'Word_count':len(arr),'Unique_words':len(st),'Vowel_count':cnt}





#main:
raw_feedback = "The delivery was quick, the packaging was neat, and the product is excellent!"
cleaned_str = clean_feedback(raw_feedback)
print("Raw_feedback: ",raw_feedback)
print("Cleaned Feedback: ",cleaned_str)
print("Feedback analysis summary: ",analyze_feedback(raw_feedback,cleaned_str))
