import pandas as pd
import numpy as np

df = pd.read_csv("/myapp/tips.csv")
print(df.iloc[0])
