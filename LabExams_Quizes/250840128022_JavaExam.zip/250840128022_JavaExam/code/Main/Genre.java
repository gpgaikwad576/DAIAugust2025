package Main;

public enum Genre {
    ACTION,DRAMA,COMEDY,HORROR,DOCUMENTRY;
}
