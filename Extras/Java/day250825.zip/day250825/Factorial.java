package theory;

public class Factorial {
    public static void main(String args[]){
        int number=5,ans=1;
        for(int i=number;i>=1;i--){
            ans=ans*i;
        }
        System.out.println("Factorial of "+number+" is: "+ans);
    }
}
