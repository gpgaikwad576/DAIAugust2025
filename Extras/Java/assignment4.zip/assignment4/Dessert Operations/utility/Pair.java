package utility;

import DessertOps.Dessert;

public class Pair {
    public Dessert dessert;
    public int quantity;

    public Pair(Dessert dessert, int quantity) {
        this.dessert = dessert;
        this.quantity = quantity;
    }
}

