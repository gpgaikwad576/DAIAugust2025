package theory;

public class Remote{
//    Curtain curtain;
//    public Remote(Curtain curtain){
//        this.curtain = curtain;
//    }
    public void clickButton(Curtain curtain){
        curtain.changeStatus();
    }

}