package day5;

public class SerializeData {

	public static void saveDataToFile(SerializeToFile obj)
	{
		obj.saveToFile();
	}
	
	public static void saveDataToDB(SerializeToDB obj)
	{
		obj.saveToDB();
	}
}
