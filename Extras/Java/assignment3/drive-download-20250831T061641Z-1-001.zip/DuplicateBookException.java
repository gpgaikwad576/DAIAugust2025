package day4;

public class DuplicateBookException extends Exception{

	public DuplicateBookException(String message)
	{
		super(message);
	}
}
