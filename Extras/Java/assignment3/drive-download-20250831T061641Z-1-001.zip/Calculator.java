package day2;

public class Calculator {

	public static void main(String[] args) {
		Math.add(12, 13);
		Math.add(34.5f, 30);
		Math.add(12, 13, 14);

		Math.addition(1,2,3,4,5,6,7,8,9);
		Math.addition(1,2,3,4,5,6,7,8,9,1,2,3,4,5,6,7,8,9);
	}

}
