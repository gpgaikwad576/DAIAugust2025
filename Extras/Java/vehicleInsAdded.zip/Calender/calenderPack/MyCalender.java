package calenderPack;
import DatePack.Date;
public class MyCalender {
    Date date = new Date(28,8,25);
//    public MyCalender(MyDate mydate){
//        this.date = mydate;
//    }
    public static void main(String args[]){
        System.out.println("fdffgh");
    }
}
