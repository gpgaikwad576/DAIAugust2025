package DatePack;

public class Date {
    int dd,mm,yy;
    public Date(int dd, int mm, int yy){
        this.dd = dd;
        this.mm = mm;
        this.yy = yy;
    }
}
