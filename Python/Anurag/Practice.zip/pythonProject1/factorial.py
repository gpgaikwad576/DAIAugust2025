# Calculate factorial of number

x=int(input("Enter Number:"))

res=1
for i in range(1,x+1,1):
    res*=i

print(res)

# s="hello world how are you where are you"
# print()
# print(" ".join([item[::-1] for item in s.split(" ")]))

