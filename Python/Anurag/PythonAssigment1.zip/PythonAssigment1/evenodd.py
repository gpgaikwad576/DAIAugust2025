# Find if given number is even or odd

a=int(input("Enter the Number:"))
if a%2==0:
    print(f"Number {a} is Even")

else:
    print(f"NUmber {a} is odd")