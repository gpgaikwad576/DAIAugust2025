#Write a program to calaculate sum of digits of given three digit number

a=int(input("Enter Number 1:"))
b=int(input("Entre NUmber2:"))
c=int(input("Entre NUmber3:"))

print(f"sum of a,b,c={a+b+c}")